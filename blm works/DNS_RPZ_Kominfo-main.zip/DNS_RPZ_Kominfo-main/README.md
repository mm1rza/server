# DNS_RPZ_Kominfo
DNS RPZ Sinkron Kominfo

Lakukan pengisian form data pada link berikut
http://bit.ly/FormKoneksiRPZ

DEBIAN 12

```
wget --no-check-certificate https://raw.githubusercontent.com/beryindo/DNS_RPZ_Kominfo/main/install.sh
```
```
chmod +x install.sh
```
```
sh install.sh
```
Tutorial Youtube

Install https://youtu.be/gW63F4MPAHI

Local landing page https://youtu.be/RRfxsgeNR0k
