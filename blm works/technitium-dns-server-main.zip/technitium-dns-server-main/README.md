# Technitium-dns-server
DEBIAN 12

```
hostnamectl
```
```
hostnamectl set-hostname blocked.kumara-hotspot.net
```
```
nano /etc/hosts
```
blocked.kumara-hotspot.net

```
curl -sSL https://raw.githubusercontent.com/beryindo/technitium-dns-server/main/install.sh | sudo bash
