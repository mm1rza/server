#! /bin/bash
source ${HOME}/.bashrc

cd /root/whatsapp
export NODE_ENV=development
npm run start:dev
